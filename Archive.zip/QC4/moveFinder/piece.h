//
// Created by George Thomas Alexander on 7/3/24.
//

#ifndef MOVEFINDER_PIECE_H
#define MOVEFINDER_PIECE_H


#include <cstdint>
#include <bitset>

class piece {
    std::bitset<8> directionBits = 0;
    int player; //0 for empty, 1 for red, 2 for yellow

public:
    piece();
    std::bitset<8> getDirectionBits();
    int getPlayer();
    void setPlayer(int player);
    void flipBit(int bit);
};


#endif //MOVEFINDER_PIECE_H
