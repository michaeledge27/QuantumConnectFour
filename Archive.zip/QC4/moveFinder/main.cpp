#include <iostream>
#include "state.h"
#include "piece.h"

int main() {

    state john("66656554423", 1, 1);

    std::cout << john.checkAscendingDiag() << "\n";

    return 0;
}
