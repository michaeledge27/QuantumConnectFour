//
// Created by George Thomas Alexander on 7/3/24.
//

#ifndef MOVEFINDER_STATE_H
#define MOVEFINDER_STATE_H


#include <string>
#include "piece.h"

class state {
private:
    static int const WIDTH = 7;
    static int const HEIGHT = 6;
    piece board[WIDTH][HEIGHT];     // 0 if cell is empty, 1 for first player and 2 for second player.
    int height[WIDTH];           // number of stones per column
    unsigned int moveCount;      // number of moves played since the beginning of the game.
    double probability; //likeliness of state occurring
    double blockAbility; //ability of the next connection in the sequence to be blocked
    double score;
    std::string moves;

public:
    state(const std::string& moves, double probability, double preventAbility);
    std::vector<int> countConnections(int move);
    bool isWinningMove();
    double getProbability() const;
    double getPreventAbility() const;
    double calcScore();
    bool checkVert();
    bool checkHorz();
    bool checkAscendingDiag();
    bool checkDescendingDiag();
    bool checkDiag();
    void updateDirectionBits(int x, int y);
    void updateDirectionBitsAfterPlace(int x, int y);
    int calculateBlockAbility();
    std::vector<int> getOpenCols();
    std::vector<state> getPossibleStates();
    piece* getBoard();



};
#endif //MOVEFINDER_STATE_H
