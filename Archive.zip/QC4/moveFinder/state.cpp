#include <vector>
#include <iostream>
#include "state.h"

state::state(const std::string &moves, double probability, double preventAbility) : height{0}, board{piece()} {
    this->moves = moves;
    moveCount = 0;
    score = 0;
    this->blockAbility = preventAbility;
    this->probability = probability;
    //init board
    for (char move: moves) {
        //digits are 48-57 in ASCII, so char - 48 = digit
        if (move - 48 > 6 || move - 48 < 0) {
            std::cout << "Invalid move set!" << "\n";
            exit(0);
        }
        if (height[move - 48] < 6) {
            int currentPlayer = 1 + moveCount % 2;
            board[height[move - 48]][move - 48].setPlayer(currentPlayer);
            updateDirectionBitsAfterPlace(move - 48, height[move - 48]);
            height[move - 48]++;
            moveCount++;
        }
    }
}

void state::updateDirectionBitsAfterPlace(int x, int y) {
    piece subject = board[y][x];
    updateDirectionBits(x, y);
    //Left
    if (x - 1 >= 0) {
        if (board[y][x - 1].getPlayer() == subject.getPlayer() && subject.getPlayer() != 0) {
            updateDirectionBits(x - 1, y);
        }
    }
    //Right
    if (x + 1 < WIDTH) {
        if (board[y][x + 1].getPlayer() == subject.getPlayer() && subject.getPlayer() != 0) {
            updateDirectionBits(x + 1, y);
        }
    }
    //Up
    if (y + 1 < HEIGHT) {
        if (board[y + 1][x].getPlayer() == subject.getPlayer() && subject.getPlayer() != 0) {
            updateDirectionBits(x, y + 1);
        }
    }
    //Down
    if (y - 1 >= 0) {
        if (board[y - 1][x].getPlayer() == subject.getPlayer() && subject.getPlayer() != 0) {
            updateDirectionBits(x, y - 1);
        }
    }
    //Left-Up
    if (x - 1 >= 0 && y + 1 < HEIGHT) {
        if (board[y + 1][x - 1].getPlayer() == subject.getPlayer() &&
            subject.getPlayer() != 0) { //top left and bottom right
            updateDirectionBits(x - 1, y + 1);
        }
    }
    //Left-Down
    if (y - 1 >= 0 && x - 1 >= 0) {
        if (board[y - 1][x - 1].getPlayer() == subject.getPlayer() && subject.getPlayer() != 0) {
            updateDirectionBits(x - 1, y - 1);
        }
    }
    //Right-Up
    if (y + 1 < HEIGHT && x + 1 < WIDTH) {
        if (board[y + 1][x + 1].getPlayer() == subject.getPlayer() && subject.getPlayer() != 0) {
            updateDirectionBits(x + 1, y + 1);
        }
    }
    //Right-Down
    if (x + 1 < WIDTH && y - 1 >= 0) {
        if (board[y - 1][x + 1].getPlayer() == subject.getPlayer() &&
            subject.getPlayer() != 0) { //bottom left and top right
            updateDirectionBits(x + 1, y - 1);
        }
    }
}

/**Flips the appropriate bits for a piece's direction bits*/
void state::updateDirectionBits(int x, int y) {
    piece *subject = &board[y][x];
    //from RIGHT to left the bit order is: Left, Right, Up, Down, Left-Up, Left-Down, Right-Up, Right-Down
    //Left
    if (x - 1 >= 0) {
        if (board[y][x - 1].getPlayer() == subject->getPlayer()) {
            int bitToFlip = 0;
            subject->flipBit(bitToFlip);
        }
    }
    //Right
    if (x + 1 < WIDTH) {
        if (board[y][x + 1].getPlayer() == subject->getPlayer()) {
            int bitToFlip = 1;
            subject->flipBit(bitToFlip);
        }
    }
    //Up
    if (y + 1 < HEIGHT) {
        if (board[y + 1][x].getPlayer() == subject->getPlayer()) {
            int bitToFlip = 2;
            subject->flipBit(bitToFlip);
        }
    }
    //Down
    if (y - 1 >= 0) {
        if (board[y - 1][x].getPlayer() == subject->getPlayer()) {
            int bitToFlip = 3;
            subject->flipBit(bitToFlip);
        }
    }
    //Top left
    if (x - 1 >= 0 && y + 1 < HEIGHT) {
        if (board[y + 1][x - 1].getPlayer() == subject->getPlayer()) {
            int bitToFlip = 4;
            subject->flipBit(bitToFlip);
        }
    }
    //Bottom left
    if (y - 1 >= 0 && x - 1 >= 0) {
        if (board[y - 1][x - 1].getPlayer() == subject->getPlayer()) {
            int bitToFlip = 5;
            subject->flipBit(bitToFlip);
        }
    }
    //Top right
    if (y + 1 < HEIGHT && x + 1 < WIDTH) {
        if (board[y + 1][x + 1].getPlayer() == subject->getPlayer()) {
            int bitToFlip = 6;
            subject->flipBit(bitToFlip);
        }
    }
    //Bottom right
    if (x + 1 < WIDTH && y - 1 >= 0) {
        if (board[y - 1][x + 1].getPlayer() == subject->getPlayer()) {
            int bitToFlip = 7;
            subject->flipBit(bitToFlip);
        }
    }
}

/**@return the number of pieces on the board connect to 3 other pieces*/
std::vector<int> state::countConnections(int col) {
    piece subject = board[height[col]][col];
    std::vector<int> connections;

    int verticalCons = 0;
    int horizontalCons = 0;
    int ascendingCons = 0;
    int descendingCons = 0;

    if ((subject.getDirectionBits() & (std::bitset<8>) 10000000) == (std::bitset<8>) 10000000) {
        descendingCons++;
    }
    if ((subject.getDirectionBits() & (std::bitset<8>) 01000000) == (std::bitset<8>) 01000000) {
        ascendingCons++;
    }
    if ((subject.getDirectionBits() & (std::bitset<8>) 00100000) == (std::bitset<8>) 00100000) {
        ascendingCons++;
    }
    if ((subject.getDirectionBits() & (std::bitset<8>) 00010000) == (std::bitset<8>) 00010000) {
        descendingCons++;
    }
    if ((subject.getDirectionBits() & (std::bitset<8>) 00001000) == (std::bitset<8>) 00001000) {
        verticalCons++;
    }
    if ((subject.getDirectionBits() & (std::bitset<8>) 00000100) == (std::bitset<8>) 00000100) {
        verticalCons++;
    }
    if ((subject.getDirectionBits() & (std::bitset<8>) 00000010) == (std::bitset<8>) 00000010) {
        horizontalCons++;
    }
    if ((subject.getDirectionBits() & (std::bitset<8>) 00000001) == (std::bitset<8>) 00000001) {
        horizontalCons++;
    }

    connections.push_back(verticalCons);
    connections.push_back(horizontalCons);
    connections.push_back(ascendingCons);
    connections.push_back(descendingCons);

    return connections;
}

/**@return probability of the state*/
double state::getProbability() const {
    return probability;
}

//@TODO
/**@return blockAbility of a state*/
double state::getPreventAbility() const {
    return blockAbility;
}

/**@return returns true if there is a vertical group, false otherwise*/
bool state::checkVert() {
    int lastMove = moves[moves.size() - 1] - 48;
    int lastMoveHeight = height[lastMove] - 1;
    int downCounter = 0;
    std::bitset<8> moveBits = board[lastMoveHeight][lastMove].getDirectionBits();
    piece downBitPiece;
    piece upBitPiece;
    downBitPiece.flipBit(3);
    upBitPiece.flipBit(2);
    std::bitset<8> downBit = downBitPiece.getDirectionBits();
    while ((moveBits & downBit) == downBit) {
        downCounter++;
        moveBits = board[lastMoveHeight - downCounter][lastMove].getDirectionBits();
    }
    return downCounter == 3;
}

/**@return returns true if there is a horizontal group, false otherwise*/
bool state::checkHorz() {
    int lastMove = moves[moves.size() - 1] - 48;
    int lastMoveHeight = height[lastMove] - 1;
    piece leftBitPiece;
    piece rightBitPiece;
    leftBitPiece.flipBit(0);
    rightBitPiece.flipBit(1);
    std::bitset<8> leftBit = leftBitPiece.getDirectionBits();
    std::bitset<8> rightBit = rightBitPiece.getDirectionBits();
    std::bitset<8> moveBits = board[lastMoveHeight][lastMove].getDirectionBits();
    int countLeft = 0;
    int countRight = 0;

    while ((moveBits & leftBit) == leftBit) {
        countLeft--;
        moveBits = board[lastMoveHeight][lastMove + countLeft].getDirectionBits();
    }

    if (countLeft == -3){
        return true;
    }

    while ((moveBits & rightBit) == rightBit) {
        countRight++;
        moveBits = board[lastMoveHeight][lastMove + countLeft + countRight].getDirectionBits();
    }
    return countRight == 3;
}

/**@return returns true if there is an ascending diagonal group, false otherwise*/
bool state::checkAscendingDiag() {
    int lastMove = moves[moves.size() - 1] - 48;
    int lastMoveHeight = height[lastMove] - 1;
    int countDescend = 0;
    int countAscend = 0;
    std::bitset<8> moveBits = board[lastMoveHeight][lastMove].getDirectionBits();
    piece leftDownBitPiece;
    piece rightUpBitPiece;
    rightUpBitPiece.flipBit(6);
    leftDownBitPiece.flipBit(5);
    std::bitset<8> leftDownBit = leftDownBitPiece.getDirectionBits();
    std::bitset<8> rightUpBit = rightUpBitPiece.getDirectionBits();
    //start going down to the left
        while ((moveBits & leftDownBit) == leftDownBit) {            //check to make sure it has a neighbor in that direction
            countDescend++;
            moveBits = board[lastMoveHeight - countDescend][lastMove - countDescend].getDirectionBits();

        }

    if (countDescend == 3) {
        return true;
    }
    //go up to the right
        while ((moveBits & rightUpBit) == rightUpBit) {
            countAscend++;
            moveBits = board[lastMoveHeight + countAscend - countDescend][lastMove + countAscend - countDescend].getDirectionBits();
        }

    if (countAscend == 3) {
        return true;
    }
    return false;
}

/**@return returns true if there is an ascending diagonal group, false otherwise*/
bool state::checkDescendingDiag() {
    int lastMove = moves[moves.size() - 1] - 48;
    int lastMoveHeight = height[lastMove] - 1;
    int countDescend = 0;
    int countAscend = 0;
    std::bitset<8> moveBits = board[lastMoveHeight][lastMove].getDirectionBits();
    piece leftUpBitPiece;
    piece rightDownBitPiece;
    leftUpBitPiece.flipBit(4);
    rightDownBitPiece.flipBit(7);
    std::bitset<8> leftUpBit = leftUpBitPiece.getDirectionBits();
    std::bitset<8> rightDownBit = rightDownBitPiece.getDirectionBits();

    //start going down to the right
    while ((moveBits & rightDownBit) == rightDownBit) {
        countDescend++;
        moveBits = board[lastMoveHeight - countDescend][lastMove + countDescend].getDirectionBits();

    }

    if (countDescend == 3) {
        return true;
    }
    //decrement countDescend because the do loop runs one more time than necessary;
    //go up to the left
    while ((moveBits & leftUpBit) == leftUpBit) {
        countAscend++;
        moveBits = board[lastMoveHeight - countDescend + countAscend][lastMove + countDescend -
                                                                      countAscend].getDirectionBits();

    }

    if (countAscend == 3) {
        return true;
    }
    return false;
}

bool state::checkDiag() {
    return checkDescendingDiag() || checkAscendingDiag();
}


/**@return true if is the winning move, false otherwise*/
bool state::isWinningMove() {
    return checkVert() || checkDiag() || checkHorz();
}

//@TODO
/**@return 0 if move can be blocked, 1 if the move cannot be blocked*/
int state::calculateBlockAbility() {
    int lastMove = moves[moves.size() - 1] - 48;
    int heightOfLastMove = height[lastMove];
    std::bitset<8> directionBits = board[heightOfLastMove][lastMove].getDirectionBits();
}

/**@return A weighted score multiplied by the probability of that state*/
double state::calcScore() {
    int lastMove = moves[moves.size() - 1] - 48;
    std::vector<int> connections = countConnections(lastMove);
    int vertical = connections[0];
    int horizontal = connections[1];
    int ascending = connections[2];
    int descending = connections[3];
    double score = ascending * 1.5 + descending * 1.5 + vertical * 1 + horizontal * 1 - probability; //weights
    /*@todo could possibly factor in a weight for block-ability of placement and need to score winning move highest
     *@todo also need to factor in blocking placement of opponent's piece this gives quantum moves an advantage over
     *@todo classical moves, maybe give classical moves a block-ability of 1 for 100% probability if can be blocked
     *@todo and give quantum moves a 0.5 for 50% probability if can be blocked*/
    return score * probability;
}

/**@return a vector containing all open columns*/
std::vector<int> state::getOpenCols() {
    std::vector<int> openCols;
    for (int dx = 0; dx < WIDTH; dx++) {
        if (height[dx] < 6) {
            openCols.push_back(dx);
        }
    }
    return std::vector<int>();
}

/**@return a vector containing all possible quantum states*/
std::vector<state> state::getPossibleStates() {
    std::vector<state> possibleStates;
    std::vector<int> openCols = getOpenCols();

    for (int col: openCols) {
        std::string column = std::to_string(col + 48 + 1); // plus one for reverse zero indexing
        possibleStates.push_back(state(moves.append(column), probability * 0.5, 0.5 * blockAbility));
        possibleStates.push_back(state(moves.append(column), probability * 1, 1 * blockAbility));
    }
    return possibleStates;
}

piece *state::getBoard() {
    return &board[0][0];
}

