//
// Created by George Thomas Alexander on 7/3/24.
//

#include "piece.h"
#include <bitset>
#include <iostream>

piece::piece() : directionBits{0} {
    player = 0;
}

/**Flips the bit in the direction + 1 position*/
void piece::flipBit(int direction) {
    std::bitset<8> newDirection = 1 << direction;
    this->directionBits = directionBits | newDirection;
}

/**Left, Right, Up, Down, Left-Up, Left-Down, Right-Up, Right-Down*/
std::bitset<8> piece::getDirectionBits() {
    return directionBits;
}

void piece::setPlayer(int player) {
    this->player = player;
}

int piece::getPlayer(){
    return player;
}


