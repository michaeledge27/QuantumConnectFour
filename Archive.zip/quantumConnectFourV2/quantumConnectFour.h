#ifndef QUANTUMCONNECTFOURV2_QUANTUMCONNECTFOUR_H
#define QUANTUMCONNECTFOURV2_QUANTUMCONNECTFOUR_H

#include <string>
#include <SFML/Graphics.hpp>

const int HEIGHT = 11; //7 rows + 4 upper phantom rows for q-moves
const int WIDTH = 6; //number of columns

/**Data type to help with classifying moves*/
typedef struct Move {
    bool classic; //true if classic move
    bool isRed; //true if belongs to Red player
    int colOne; //first column of quantum Move
    int colTwo; //second column of quantum Move, same as first if classic Move
    bool measured;
} Move;

bool checkVertical(int col, std::string board[HEIGHT][WIDTH]);

bool checkHorizontal(int col, std::string board[HEIGHT][WIDTH]);

bool checkAscending(int col, std::string board[HEIGHT][WIDTH]);

bool checkDescending(int col, std::string board[HEIGHT][WIDTH]);

bool checkEnding(int col, std::string board[HEIGHT][WIDTH]);

int findDepth(int col, std::string board[HEIGHT][WIDTH]);

bool halfQuantumMove(int col);      //GT

bool classicalMove(int col);        //GT

void measure(std::vector<Move> movesMade); //GT

void drawBoard(sf::RenderWindow window); //ME, done

void drawPieces(std::vector<Move>, sf::RenderWindow); //ME

void drawTurnInProgress(int position, sf::RenderWindow); //ME

void handleKeyPress(sf::Event, sf::RenderWindow);  //GT

void measureCountdown(sf::RenderWindow& window, int count);       //ME, done

void drawBeginScreen(sf::RenderWindow& window); //ME, done

void drawEndScreen(sf::RenderWindow& window, const std::string& winner, int moveCount);   //ME, done

std::string* updateBoard(std::vector<Move> movesMade); //Returns pointer to an array we will initialize on the heap





#endif //QUANTUMCONNECTFOURV2_QUANTUMCONNECTFOUR_H
