#include "quantumConnectFour.h"
#include <iostream>
/**
 * Checks for a horizontal group at the highest occupied position in the given column
 * @param col -> column where the last piece was placed on the board
 * @param board -> pointer to an array of strings that serves as our board
 * @return true if there is a horizontal group, false otherwise
 */
bool checkHorizontal(int col, std::string board[HEIGHT][WIDTH]) {
    int leftCount = 0;
    int rightCount = 0;
    int row = findDepth(col, board);
    std::string color = board[row][col];
    bool redOrYellow = color == "YYY" || color == "RRR"; //ensure that the four matching are full pieces
    //count connections to the left
    while (col - leftCount > 0) {
        leftCount++;
        //look at spot to the left, if it matches continue, if it doesn't then decrement counter and break;
        if (board[row][col - leftCount] == color) {
            continue;
        } else {
            leftCount--;
            break;
        }
    }
    //if it has 3 or more connections to the left then there is a group
    if (leftCount > 3 && redOrYellow) {
        return true;
    }
    //count connections to the right
    while (col + rightCount < WIDTH) {
        rightCount++;
        //look at spot to the right, if it matches continue, if it doesn't then decrement counter and break;
        if (board[row][col + rightCount] == color) {
            continue;
        } else {
            rightCount--;
            break;
        }
    }
    //if the total connections to the right and left is greater than or equal to three then there is a group
    return leftCount + rightCount >= 3 && redOrYellow;
}


/**
 * Checks for a vertical group starting at the highest occupied position in the given column
 * @param col -> the column the last piece was placed in
 * @param board -> the logic representation of our connect 4 board
 * @return true if the last piece placed in the given column forms a vertical group
 */
bool checkVertical(int col, std::string board[HEIGHT][WIDTH]) {
    int row = findDepth(col, board);
    int countDown = 0;
    std::string color = board[row][col];
    bool redOrYellow = color == "YYY" || color == "RRR"; //ensure that the four matching are full pieces

    while (row - countDown > 0) {
        countDown++;
        //look at spot below, if it matches continue, if it doesn't then decrement counter and break;
        if (board[row - countDown][col] == color) {
            continue;
        } else {
            countDown--;
            break;
        }
    }
    return countDown >= 3 && redOrYellow;
}

/**
 * Function to check if there is a four in a row connection in the ascending direction, left to right.
 * @param col what column the piece was most recently placed in
 * @param board current state of the board
 * @return true if there is a four in a row connection, false otherwise.
 */
bool checkAscending(int col, std::string board[HEIGHT][WIDTH]) {
    int leftDownCount = 0;
    int rightUpCount = 0;
    int row = findDepth(col, board);
    std::string color = board[row][col];
    bool fullPieceCheck = color == "YYY" || color == "RRR"; //ensure that the four matching are full pieces

    // check in the left down direction how many connections there are
    while (col - leftDownCount > 0 && row - leftDownCount > 0) {
        leftDownCount++;
        if (board[row - leftDownCount][col - leftDownCount] == color) {
            continue;
        } else {
            leftDownCount--;
            break;
        }
    }

    // return true if the most recent piece was the top right part of the connection
    if (leftDownCount >= 3 && fullPieceCheck) {
        return true;
    }

    // check in the right up direction how many connections there are
    while (col + rightUpCount < WIDTH && row + rightUpCount < HEIGHT) {
        rightUpCount++;
        if (board[row + rightUpCount][col + rightUpCount] == color) {
            continue;
        } else {
            rightUpCount--;
            break;
        }
    }

    // return total number of connections and ensure that it only full pieces are being checked
    return rightUpCount + leftDownCount >= 3 && fullPieceCheck;
}

/**
 * Checks for a descending group at the highest occupied position in the given column
 * @param col -> column the last piece was placed in
 * @param board -> the logic representation of the board
 * @return true if the last piece placed in the given col forms a descending group, false otherwise*.
 */
bool checkDescending(int col, std::string board[HEIGHT][WIDTH]) {
    int row = findDepth(col, board);
    int countDown = 0;
    int countUp = 0;
    std::string color = board[row][col];
    bool redOrYellow = color == "YYY" || color == "RRR";
    //count connections going down and to the right
    //look down to the right, if it matches continue, otherwise decrement the counter and break
    while (col + countDown < WIDTH && row - countDown > 0) {
        countDown++;
        if (board[row - countDown][col + countDown] == color) {
            continue;
        } else {
            countDown--;
            break;
        }
    }

    //if there were three connections of full pieces down and to the right then return true
    if (countDown >= 3 && redOrYellow) {
        return true;
    }

    //same loop as above but counting upward connections now
    while (col - countUp > 0 && row + countDown < HEIGHT) {
        countUp++;
        if (board[row + countUp][col - countUp] == color) {
            continue;
        } else {
            countUp--;
            break;
        }
    }

    //if total number of connections of full pieces is greater than or equal three return true
    return countDown + countUp >= 3 && redOrYellow;
}

/**Checks to see if someone has won the game, or if there is a draw
 * @param col -> column last piece was placed in
 * @param board -> logical representation of the board
 * @return true if the game is over, false otherwise*/
bool checkEnding(int col, std::string board[HEIGHT][WIDTH]){
    int pieceCount = 0;
    //count number of full pieces on the board, if equal to 42 then there is a draw
    for (int y = 0; y < HEIGHT; y++){
        for (int x = 0; x < WIDTH; x++){
            if (board[y][x] == "YYY" || board[y][x] == "RRR"){
                pieceCount++;
            }
        }
    }
    return checkDescending(col, board) || checkAscending(col, board) || checkVertical(col, board) || checkHorizontal(col, board) || pieceCount == 42;
}

/** Returns the height up to which pieces have been played in a given column
 * @param col -> column to check depth in
 * @return -> row in which a piece can be placed
 * */
int findDepth(int col, std::string board[HEIGHT][WIDTH]) {
    int depth = 9;
    while (depth > 0) {
        if (board[depth][col] == "XXX") {
            depth--;
        } else { break; }
    }
    return depth;
}

void drawBoard(sf::RenderWindow window) {
    int xCells = 7; // Number of columns
    int yCells = 6; // Number of rows
    float horizontalSpace = 100.0f; // Horizontal space between cells
    float verticalSpace = 100.0f; // Vertical space between cells

    // Draw columns
    for (int x = 1; x <= xCells; ++x) {
        sf::RectangleShape verticalLine(sf::Vector2f(5, verticalSpace * (yCells - 2)));
        verticalLine.setFillColor(sf::Color::Black);
        verticalLine.setPosition(horizontalSpace * x, verticalSpace * 4);
        window.draw(verticalLine);
    }

    // Draw rows
    for (int y = 4; y < yCells + 3; ++y) {
        sf::RectangleShape horizontalLine(sf::Vector2f(horizontalSpace * (xCells - 2) + 5, 5));
        horizontalLine.setFillColor(sf::Color::Black);
        horizontalLine.setPosition(horizontalSpace, verticalSpace * y);
        window.draw(horizontalLine);
    }
}

void drawTurnInProgress(int position, sf::RenderWindow) {
    //@TODO implement this function to draw both a classic and quantum turn in progress
}

void drawPieces(std::vector<Move>, sf::RenderWindow) {
    //@TODO implement this function to draw pieces on the board

}

void measureCountdown(sf::RenderWindow& window, int count){
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        std::cerr << "Failed to load font!" << std::endl;
    }
    sf::Text text;
    text.setFont(font);
    text.setString("Countdown: " + std::to_string(count));
    text.setCharacterSize(24);
    text.setFillColor(sf::Color::Black);
    text.setPosition(10, 10);
    window.draw(text);
}

void drawBeginScreen(sf::RenderWindow& window) {
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        std::cerr << "Failed to load font!" << std::endl;
    }
    std::vector<std::string> instructions = {
            "Connect Four Instructions:",
            "1. The game is played on a grid.",
            "2. Players take turns dropping pieces into columns.",
            "3. The goal is to connect four pieces in a row, column, or diagonal.",
            "4. Press the space key to start the game.",
    };

    sf::Text text;
    text.setFont(font);
    text.setCharacterSize(24);
    text.setFillColor(sf::Color::Black);

    for (size_t i = 0; i < instructions.size(); ++i) {
        text.setString(instructions[i]);
        text.setPosition(50, 50 + i * 30);
        window.draw(text);
    }
}

void drawEndScreen(sf::RenderWindow& window, const std::string& winner, int moveCount) {
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        std::cerr << "Failed to load font!" << std::endl;
    }
    std::string endMessage = "Player " + winner + " wins!\nMoves taken: " + std::to_string(moveCount);
    sf::Text text;
    text.setFont(font);
    text.setString(endMessage);
    text.setCharacterSize(24);
    text.setFillColor(sf::Color::Black);
    text.setPosition(50, 50);
    window.draw(text);
}




